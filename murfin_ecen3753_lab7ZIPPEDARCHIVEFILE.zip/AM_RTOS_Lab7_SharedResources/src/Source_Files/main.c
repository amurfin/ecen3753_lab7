/***************************************************************************//**
 * @file
 * @brief Simple LED Blink Demo for SLSTK3402A
 *******************************************************************************
 * # License
 * <b>Copyright 2018 Silicon Laboratories Inc. www.silabs.com</b>
 *******************************************************************************
 *
 * The licensor of this software is Silicon Laboratories Inc. Your use of this
 * software is governed by the terms of Silicon Labs Master Software License
 * Agreement (MSLA) available at
 * www.silabs.com/about-us/legal/master-software-license-agreement. This
 * software is distributed to you in Source Code format and is governed by the
 * sections of the MSLA applicable to Source Code.
 *
 ******************************************************************************/

#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "em_device.h"
#include "em_chip.h"
#include "em_emu.h"
#include "bsp.h"
#include "main.h"
#include "app.h"
#include "gpio.h"
#include "capsense.h"
#include "display.h"
#include "textdisplay.h"
#include "retargettextdisplay.h"

// Micrium OS Includes
#include  <bsp_os.h>
#include  "bsp.h"
#include  <cpu/include/cpu.h>
#include  <common/include/common.h>
#include  <kernel/include/os.h>
#include  <kernel/include/os_trace.h>
#include  <common/include/lib_def.h>
#include  <common/include/rtos_utils.h>
#include  <common/include/toolchains.h>

volatile uint32_t msTicks; /* counts 1ms timeTicks */

/* LOCAL TASK STATIC PROTOTYPES */
static  void  MainStartTask (void  *p_arg);
static  void  IdleTask (void  *p_arg);
static  void  SpeedSetpointTask (void  *p_arg);
static  void  VehicleDirectionTask (void  *p_arg);
static  void  VehicleMonitorTask (void  *p_arg);
static  void  LCDDisplayTask (void  *p_arg);
static  void  LEDOutputTask (void  *p_arg);
static	void  VehicleDirectionInputTimerCallback (OS_TMR p_tmr, void * p_arg);
static	void  LCDDisplayTimerCallback (OS_TMR p_tmr, void * p_arg);

// Micrium OS Tasks
/* Start Task Stack.                                    */
static  CPU_STK  	MainStartTaskStk[MAIN_START_TASK_STK_SIZE];
/* Start Task TCB.                                      */
static  OS_TCB   	MainStartTaskTCB;
/* Idle Task Stack.                                    */
static  CPU_STK  	IdleTaskStk[IDLE_TASK_STK_SIZE];
/* Idle Task TCB.                                      */
static  OS_TCB   	IdleTaskTCB;
/* Speed Setpoint Task Stack.                                    */
static  CPU_STK  	SpeedSetpointTaskStk[SPEED_SETPOINT_TASK_STK_SIZE];
/* Speed Setpoint Task TCB.                                      */
static  OS_TCB   	SpeedSetpointTaskTCB;
/* Vehicle Direction Task Stack.                                    */
static  CPU_STK  	VehicleDirectionTaskStk[VEHICLE_DIRECTION_TASK_STK_SIZE];
/* Vehicle Direction Task TCB.                                      */
static  OS_TCB   	VehicleDirectionTaskTCB;
/* Vehicle Monitor Task Stack.                                    */
static  CPU_STK  	VehicleMonitorTaskStk[VEHICLE_MONITOR_TASK_STK_SIZE];
/* Vehicle Monitor Task TCB.                                      */
static  OS_TCB   	VehicleMonitorTaskTCB;
/* LCD Display Task Stack.                                    */
static  CPU_STK  	LCDDisplayTaskStk[LCD_DISPLAY_TASK_STK_SIZE];
/* LCD Display Task TCB.                                      */
static  OS_TCB   	LCDDisplayTaskTCB;
/* LED Output Task Stack.                                    */
static  CPU_STK  	LEDOutputTaskStk[LED_OUTPUT_TASK_STK_SIZE];
/* LED Output Task TCB.                                      */
static  OS_TCB   	LEDOutputTaskTCB;
/* Vehicle Direction Slider Input Timer */
static	OS_TMR		VehicleDirectionInputTimer;
/* Periodic LCD Display Timer */
static	OS_TMR		LCDDisplayTimer;

// Micrium OS Objects
static	OS_FLAG_GRP	VehicleMonitorFlags;
static	OS_FLAG_GRP	LEDOutputFlags;
static	OS_SEM		SpeedSetpointSemaphore;
static	OS_SEM		VDITimerSemaphore; 		// Vehicle Direction Input Timer Semaphore
static 	OS_SEM		LCDDisplaySemaphore;	// sempahore for periodic lcd display task timer
static	OS_MUTEX	SpeedSetpointMutex;
static	OS_MUTEX	VehicleDirectionMutex;


// Speed Setpoint Global Static struct instantiation
static struct speed_setpoint vehicleSpeed;

// Vehicle direction setpoint global static struct instantiation
static struct direction_setpoint vehicleDirection;



int main(void) {
	  RTOS_ERR err;
	  BSP_SystemInit();
	  CPU_Init();                                                 /* Initialize CPU.                                      */

	  OS_TRACE_INIT();
	  OSInit(&err);                                               /* Initialize the Kernel.                               */
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  // add startupt task & start OS kernel
	  OSTaskCreate(&MainStartTaskTCB,                          /* Create the Start Task.                               */
	               "Main Start Task",
	                MainStartTask,
	                DEF_NULL,
	                MAIN_START_TASK_PRIO,
	               &MainStartTaskStk[0],
	               (MAIN_START_TASK_STK_SIZE / 10u),
	                MAIN_START_TASK_STK_SIZE,
	                0u,
	                0u,
	                DEF_NULL,
	               (OS_OPT_TASK_STK_CLR),
	               &err);
	                                                              /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  OSStart(&err);                                              /* Start the kernel.                                    */
	  /*   Check error code.                                  */
	  APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

	  return 1;
}

/**
 * @brief
 * OS Helper function, to post the speed setpoint semaphore for the gpio isr
 *
 * @details
 * Called by IRQHandler in gpio.c
 */
void postButtonSemaphore(void)
{
	RTOS_ERR err;
	OSSemPost(&SpeedSetpointSemaphore,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * Vehicle Direction input timer callback function
 *
 * @details
 * Posts to semaphore for periodic capsense slider measurements
 */
static	void  VehicleDirectionInputTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&VDITimerSemaphore,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief
 * LCD Display timer callback function
 *
 * @details
 * Posts to semaphore for periodic LCD Display Task
 */
static	void  LCDDisplayTimerCallback (OS_TMR p_tmr, void * p_arg)
{
	RTOS_ERR err;
	OSSemPost(&LCDDisplaySemaphore,
			OS_OPT_POST_ALL,
			&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

////////////////////////////////////////////////////////////////////////////////////////
// OS Task Functions //
/*
*********************************************************************************************************
*                                          MainStartTask()
*
* Description : This is the task that will be called by the Startup when all services are initializes
*               successfully.
*
* Argument(s) : p_arg   Argument passed from task creation. Unused, in this case.
*
* Return(s)   : None.
*
* Notes       : None.
*********************************************************************************************************
*/
static  void  MainStartTask (void  *p_arg)
{
    RTOS_ERR  err;


    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    Common_Init(&err);                                          /* Call common module initialization example.           */
    APP_RTOS_ASSERT_CRITICAL(err.Code == RTOS_ERR_NONE, ;);

	EMU_DCDCInit_TypeDef dcdcInit = EMU_DCDCINIT_DEFAULT;
	CMU_HFXOInit_TypeDef hfxoInit = CMU_HFXOINIT_DEFAULT;


	CHIP_Init();


	EMU_EM23Init_TypeDef em23Init = EMU_EM23INIT_DEFAULT;
	EMU_DCDCInit(&dcdcInit);
	em23Init.vScaleEM23Voltage = emuVScaleEM23_LowPower;
	EMU_EM23Init(&em23Init);
	CMU_HFXOInit(&hfxoInit);


	CMU_OscillatorEnable(cmuOsc_HFRCO, true, true);
	CMU_ClockSelectSet(cmuClock_HF, cmuSelect_HFRCO);
	CMU_OscillatorEnable(cmuOsc_HFXO, false, false);


	CMU_ClockEnable(cmuClock_GPIO, true);

    app_peripheral_setup();

    /* Initialize the display module. */
    DISPLAY_Init();

    /* Retarget stdio to a text display. */
    if (RETARGET_TextDisplayInit() != TEXTDISPLAY_EMSTATUS_OK) {
      while (1) ;
    }

	// create all OS objects (2x flaggrps, 2x mutex, 1x semaphore)
	// Vehicle Monitor Flag Group
	OSFlagCreate(&VehicleMonitorFlags,
				"Vehicle Monitor Flags",
				EVENT_FLAGS_INITILZIED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED Output Flag Group
	OSFlagCreate(&LEDOutputFlags,
				"LED Output Flags",
				EVENT_FLAGS_INITILZIED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Speed Setpoint semaphore
	OSSemCreate(&SpeedSetpointSemaphore,
				"Speed Setpoint Semaphore",
				SEM_INITIALIZED_CLEAR,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Speed Setpoint Mutex
	OSMutexCreate(&SpeedSetpointMutex,
				"Speed Setpoint Mutex",
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Vehicle Direction Mutex
	OSMutexCreate(&VehicleDirectionMutex,
				"Vehicle Direction Mutex",
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Vehicle Direction Slider Input Timer
	OSTmrCreate(&VehicleDirectionInputTimer,
			   "Vehicle Direction Input Timer",
			   0,
			   1,
			   OS_OPT_TMR_PERIODIC,
			   &VehicleDirectionInputTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Display Timer
	OSTmrCreate(&LCDDisplayTimer,
			   "LCD Display Timer",
			   0,
			   1,
			   OS_OPT_TMR_PERIODIC,
			   &LCDDisplayTimerCallback,
			   NULL,
			   &err);
	// check error code
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Vehicle Direction Input Timer semaphore
	OSSemCreate(&VDITimerSemaphore,
				"Vehicle Direction Input Timer Semaphore",
				0,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Display Timer semaphore
	OSSemCreate(&LCDDisplaySemaphore,
				"LCD Display Timer Semaphore",
				0,
				&err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // Create all other tasks
	// Idle Task Create
	OSTaskCreate(&IdleTaskTCB,
			   "Idle Task",
				IdleTask,
				DEF_NULL,
				IDLE_TASK_PRIO,
			   &IdleTaskStk[0],
			   (IDLE_TASK_STK_SIZE / 10u),
				IDLE_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Vehicle Monitor Task Create
	OSTaskCreate(&VehicleMonitorTaskTCB,
			   "Vehicle Monitor Task",
				VehicleMonitorTask,
				DEF_NULL,
				VEHICLE_MONITOR_TASK_PRIO,
			   &VehicleMonitorTaskStk[0],
			   (VEHICLE_MONITOR_TASK_STK_SIZE / 10u),
			   VEHICLE_MONITOR_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Speed Setpoint Task Create
	OSTaskCreate(&SpeedSetpointTaskTCB,
			   "Speed Setpoint Task",
				SpeedSetpointTask,
				DEF_NULL,
				SPEED_SETPOINT_TASK_PRIO,
			   &SpeedSetpointTaskStk[0],
			   (SPEED_SETPOINT_TASK_STK_SIZE / 10u),
				SPEED_SETPOINT_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// Vehicle Direction Task Create
	OSTaskCreate(&VehicleDirectionTaskTCB,
			   "Vehicle Direction Task",
				VehicleDirectionTask,
				DEF_NULL,
				VEHICLE_DIRECTION_TASK_PRIO,
			   &VehicleDirectionTaskStk[0],
			   (VEHICLE_DIRECTION_TASK_STK_SIZE / 10u),
			   VEHICLE_DIRECTION_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LCD Display Task Create
	OSTaskCreate(&LCDDisplayTaskTCB,
			   "LCD Display Task",
				LCDDisplayTask,
				DEF_NULL,
				LCD_DISPLAY_TASK_PRIO,
			   &LCDDisplayTaskStk[0],
			   (LCD_DISPLAY_TASK_STK_SIZE / 10u),
			   LCD_DISPLAY_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
	// LED Output Task Create
	OSTaskCreate(&LEDOutputTaskTCB,
			   "LED Output Task",
				LEDOutputTask,
				DEF_NULL,
				LED_OUTPUT_TASK_PRIO,
			   &LEDOutputTaskStk[0],
			   (LED_OUTPUT_TASK_STK_SIZE / 10u),
			   LED_OUTPUT_TASK_STK_SIZE,
				0u,
				0u,
				DEF_NULL,
			   (OS_OPT_TASK_STK_CLR),
			   &err);
	APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // delete self task & check error code
    OSTaskDel(NULL, &err);
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
}

/**
 * @brief OS Idle Task - custom implementation
 *
 * @details Goes into EM1
 */
static void IdleTask(void *p_arg)
{
    PP_UNUSED_PARAM(p_arg);                                     /* Prevent compiler warning.                            */

    while (INFINITE_LOOP)
    {
    	EMU_EnterEM1();
    }
}

/**
 * @brief Speed Setpoint Task
 *
 * @details
 * X
 *
 */
static void	SpeedSetpointTask(void * p_arg)
{
    RTOS_ERR  err;
    state_change_t last_state_change;
    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // initialize values of vehicle speed structure
    vehicleSpeed.curr_speed = 0;
    vehicleSpeed.cnt_increments = 0;
    vehicleSpeed.cnt_decrements = 0;

    while (INFINITE_LOOP)
    {
    	// get speed command data
    	// pend on Speed Setpoint Semaphore (waiting for gpio isr)
    	OSSemPend(&SpeedSetpointSemaphore,
    				0,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        // now that this task has control of button event fifo, read the last data from it and pop data off queue
        last_state_change = getLastStateChange();
        // no post to speed setpoint semaphore (post done by isr)

        // put speed command data into speed setpoint struct
        // pend on the speed setpoint mutex
        OSMutexPend(&SpeedSetpointMutex,
        			MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        // update speed setpoint data
        // btn0 increments speed
        if (last_state_change == btn0)
        {
        	vehicleSpeed.curr_speed += 5;
        	vehicleSpeed.cnt_increments += 1;
        }
        // btn1 decrements speed
        else if (last_state_change == btn1)
        {
        	if (vehicleSpeed.curr_speed >= 5)
        	{
        		vehicleSpeed.curr_speed -= 5;
        		vehicleSpeed.cnt_decrements += 1;
        	}
        }
        // post to speed setpoint mutex
        OSMutexPost(&SpeedSetpointMutex,
        			OS_OPT_POST_NONE,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // post to Vehicle Monitor Event Flag so it knows to look at data struct
        OSFlagPost(&VehicleMonitorFlags,
        			VEHICLE_MONITOR_FLAG_SPEED,
					OS_OPT_POST_FLAG_SET,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
    }
}

/**
 * @brief Vehicle Direction Task
 *
 * @details
 * X
 *
 */
static void	VehicleDirectionTask(void * p_arg)
{
    RTOS_ERR  err;
    int32_t sliderPositionRaw;
    direction_t currDirection;
    bool directionHasChanged;
    bool directionCollisionWarning = false;
    static bool setAlert = true;
    // math below ensures collision warning every 5sec
    static uint16_t directionCollisionWarningValue = (5 / SLIDER_INPUT_PERIOD) * 10;
    static uint16_t directionCollisionWarningCtr = 0;
    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // start OS timer (will delay an additional 100 ticks before actually starting)
    OSTmrStart(&VehicleDirectionInputTimer, &err);
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    // initilize Vehicle Direction structure values
    vehicleDirection.curr_direction = straight_forward;
    vehicleDirection.cnt_hard_lefts = 0;
    vehicleDirection.cnt_soft_lefts = 0;
    vehicleDirection.cnt_straight_forwards = 0;
    vehicleDirection.cnt_soft_lefts = 0;
    vehicleDirection.cnt_hard_lefts = 0;
    vehicleDirection.directionCollisionWarning = false;

    while (INFINITE_LOOP)
    {
		// Pend for VDI Timer Semaphore, periodically awaking this task
    	OSSemPend(&VDITimerSemaphore,
    			SEM_PEND_FOREVER,
				OS_OPT_PEND_BLOCKING,
				NULL,
				&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        // increment counter for direction collision alert timer
        directionCollisionWarningCtr += 1;

        // get slider position
        // Not touched = -1
        // far left 0-6
        // soft left 7-14
        // straight forward 15-33
        // soft right 34-39
        // hard right >39
        CAPSENSE_Sense();
        sliderPositionRaw = CAPSENSE_getSliderPosition();
        if (sliderPositionRaw < 0)
        	currDirection = no_direction;
        else if (sliderPositionRaw < 7)
        	currDirection = hard_left;
        else if (sliderPositionRaw < 15)
        	currDirection = soft_left;
        else if (sliderPositionRaw < 34)
        	currDirection = straight_forward;
        else if (sliderPositionRaw < 40)
        	currDirection = soft_right;
        else
        	currDirection = hard_right;

        // put vehicle direction data into direction setpoint struct
        // get lock on vehicle direction data struct
        OSMutexPend(&VehicleDirectionMutex,
        			MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // see if direction has changed
        if (currDirection != vehicleDirection.curr_direction && currDirection != no_direction)
        	directionHasChanged = true;
        else
        	directionHasChanged = false;

        // if it has changed, update the data struct, otherwise do nothing
        if (directionHasChanged)
        {
        	// since direction changed, reset collision alert counter and clear flag
        	directionCollisionWarningCtr = 0;
        	directionCollisionWarning = false;
        	setAlert = true;
        	vehicleDirection.directionCollisionWarning = false;
        	// input other data to struct
        	vehicleDirection.curr_direction = currDirection;
        	if (currDirection == hard_left)
        		vehicleDirection.cnt_hard_lefts += 1;
        	else if (currDirection == soft_left)
        		vehicleDirection.cnt_soft_lefts += 1;
        	else if (currDirection == straight_forward)
        		vehicleDirection.cnt_straight_forwards += 1;
        	else if (currDirection == soft_right)
        		vehicleDirection.cnt_soft_rights += 1;
        	else if (currDirection == hard_right)
        		vehicleDirection.cnt_hard_rights += 1;
        }
        // if direction hasn't changed, increment the collision alert counter
        // if counter is above threshold value, set alert flag in struct
        else
        {
            // increment counter for direction collision alert timer
            directionCollisionWarningCtr += 1;
            // if counter is above threshold, set warning/alert flag
            if (directionCollisionWarningCtr >= directionCollisionWarningValue && (!directionCollisionWarning && setAlert))
            {
            	directionCollisionWarning = true;
            	vehicleDirection.directionCollisionWarning = true;
            }
        }


        // release lock on vehicle direction data
        OSMutexPost(&VehicleDirectionMutex,
        			OS_OPT_POST_NONE,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // if we updated the direction data or have a warning, set event flag for vehicle monitor
        // "setAlert" variable only causes the flag to post once per direction time limit alert
        if (directionHasChanged || (directionCollisionWarning && setAlert))
        {
			OSFlagPost(&VehicleMonitorFlags,
					VEHICLE_MONITOR_FLAG_DIRECTION,
					OS_OPT_POST_FLAG_SET,
					&err);
			APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			if (setAlert && directionCollisionWarning)
				setAlert = false;
        }
    }
}

/**
 * @brief Vehicle Monitor Task
 *
 * @details
 * X
 *
 */
static void	VehicleMonitorTask(void * p_arg)
{
    RTOS_ERR  err;
    OS_FLAGS flaggedFlags;
    static direction_t currDirection;
    static bool directionCollisionSetAlert = false;
    static bool speedSetAlert = false;
    static uint16_t currSpeed;
    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    while (INFINITE_LOOP)
    {
    	// pend for changes to speed OR direction flags
    	flaggedFlags = OSFlagPend(&VehicleMonitorFlags,
    								0x3,
									FLAG_PEND_FOREVER,
									(OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME + OS_OPT_PEND_BLOCKING),
									NULL,
									&err);
		APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

		// get speed if speed flag
		if (flaggedFlags & VEHICLE_MONITOR_FLAG_SPEED)
		{
			// acquire speed setpoint data struct lock
			OSMutexPend(&SpeedSetpointMutex,
						MUTEX_PEND_FOREVER,
						OS_OPT_PEND_BLOCKING,
						NULL,
						&err);
			APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			// get speed status
			currSpeed = vehicleSpeed.curr_speed;
			// release speed setpoint datastruct lock
	        OSMutexPost(&SpeedSetpointMutex,
	        			OS_OPT_POST_NONE,
						&err);
	        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
		}
		// get direction if it changed
		if (flaggedFlags & VEHICLE_MONITOR_FLAG_DIRECTION)
		{
			// acquire vehicle direction data struct lock
			OSMutexPend(&VehicleDirectionMutex,
						MUTEX_PEND_FOREVER,
						OS_OPT_PEND_BLOCKING,
						NULL,
						&err);
			APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			// get direction & alert status
			currDirection = vehicleDirection.curr_direction;
			if (currSpeed == 0)
				directionCollisionSetAlert = false;
			else
				directionCollisionSetAlert = vehicleDirection.directionCollisionWarning;
			// release vehicle direction datastruct lock
	        OSMutexPost(&VehicleDirectionMutex,
	        			OS_OPT_POST_NONE,
						&err);
	        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
		}

		// check for speed violations (direction time limit / collision warning already checked by vehicledirection task)
		// check for overspeed
		if (currSpeed > 75 || (currSpeed > 45 && currDirection != straight_forward))
		{
			speedSetAlert = true;
		}
		else
			speedSetAlert = false;

		// if LED0 is off and there's a speed alert, set the speed alert set flag
		if (GPIO_PinOutGet(LED0_port, LED0_pin) == 0)
		{
			if (speedSetAlert)
			{
				// set speed alert set flag
				OSFlagPost(&LEDOutputFlags,
							ALERT_FLAG_SPEED_SET,
							OS_OPT_POST_FLAG_SET,
							&err);
		        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			}
		}
		// if LED0 is on and there's not a speed alert, set the speed alert clear flag
		else
		{
			if (!speedSetAlert)
			{
				// set speed alert clear flag
				OSFlagPost(&LEDOutputFlags,
							ALERT_FLAG_SPEED_CLEAR,
							OS_OPT_POST_FLAG_SET,
							&err);
		        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			}
		}

		// if LED1 is off and there's a direction alert, set the direction alert set flag
		if (GPIO_PinOutGet(LED1_port, LED1_pin) == 0)
		{
			if (directionCollisionSetAlert && currSpeed > 0)
			{
				// set direction alert set flag
				OSFlagPost(&LEDOutputFlags,
							ALERT_FLAG_DIRECTION_SET,
							OS_OPT_POST_FLAG_SET,
							&err);
		        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			}
		}
		// if LED1 is on and there's not a speed alert, set the speed alert clear flag
		else
		{
			if (!directionCollisionSetAlert || currSpeed == 0)
			{
				// set direction alert clear flag
				OSFlagPost(&LEDOutputFlags,
							ALERT_FLAG_DIRECTION_CLEAR,
							OS_OPT_POST_FLAG_SET,
							&err);
		        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
			}
		}
    }
}

/**
 * @brief LCD Display Task
 *
 * @details
 * X
 *
 */
static void	LCDDisplayTask(void * p_arg)
{
    RTOS_ERR  err;
    uint16_t currSpeed;
    static uint16_t lastSpeed = 3;
    direction_t currDirection;
    static direction_t lastDirection = no_direction;
    uint8_t forLoopCtr;
    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    // start OS timer (will delay an additional 100 ticks before actually starting)
    OSTmrStart(&LCDDisplayTimer, &err);
    APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

    printf("SPEED = 0\n\r");
    printf("DIRECTION = FORWARD");

    while (INFINITE_LOOP)
    {
    	// Pend on LCD Display Sempahore
    	OSSemPend(&LCDDisplaySemaphore,
    			SEM_PEND_FOREVER,
				OS_OPT_PEND_BLOCKING,
				NULL,
				&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // acquire lock on speed data
        OSMutexPend(&SpeedSetpointMutex,
        			MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        // get speed data
        currSpeed = vehicleSpeed.curr_speed;
        // release lock on speed data
        OSMutexPost(&SpeedSetpointMutex,
        			OS_OPT_POST_NONE,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // acquire lock on direction data
        OSMutexPend(&VehicleDirectionMutex,
        			MUTEX_PEND_FOREVER,
					OS_OPT_PEND_BLOCKING,
					NULL,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);
        // get direction data
        currDirection = vehicleDirection.curr_direction;
        // release lock on direction data
        OSMutexPost(&VehicleDirectionMutex,
        			OS_OPT_POST_NONE,
					&err);
        APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

        // update LCD
        // move curser to home
        printf(TEXTDISPLAY_ESC_SEQ_CURSOR_HOME_VT100);
        // if speed has changed, update screen
        if (currSpeed != lastSpeed)
        {
        	// move curser to the right 8 spaces from home to get to speed value place
        	for (forLoopCtr = 0; forLoopCtr < 8; forLoopCtr++)
        		printf(TEXTDISPLAY_ESC_SEQ_CURSOR_RIGHT_ONE_CHAR);
        	// write 4 spaces to delete existing characters
        	printf("    ");
        	// reset cursor
        	for (forLoopCtr = 0; forLoopCtr < 4; forLoopCtr++)
        		printf(TEXTDISPLAY_ESC_SEQ_CURSOR_LEFT_ONE_CHAR);
        	// print speed
        	printf("%d", currSpeed);
        }
        // move curser to home
        printf(TEXTDISPLAY_ESC_SEQ_CURSOR_HOME_VT100);
        // if direction has changed, update screen
        if (currDirection != lastDirection)
        {
        	// move curser down 1 line and to the right 12 spaces to get to place of direction
        	printf(TEXTDISPLAY_ESC_SEQ_CURSOR_DOWN_ONE_LINE);
        	for (forLoopCtr = 0; forLoopCtr < 12; forLoopCtr++)
        		printf(TEXTDISPLAY_ESC_SEQ_CURSOR_RIGHT_ONE_CHAR);
        	// write 12 spaces to delete existing characters
        	printf("            ");
        	// reset cursor
            printf(TEXTDISPLAY_ESC_SEQ_CURSOR_HOME_VT100);
        	printf(TEXTDISPLAY_ESC_SEQ_CURSOR_DOWN_ONE_LINE);
        	for (forLoopCtr = 0; forLoopCtr < 12; forLoopCtr++)
        		printf(TEXTDISPLAY_ESC_SEQ_CURSOR_RIGHT_ONE_CHAR);
        	// print direction
        	if (currDirection == hard_left)
        		printf("Hard Left");
        	else if (currDirection == soft_left)
        		printf("Slight Left");
        	else if (currDirection == straight_forward)
        		printf("Forward");
        	else if (currDirection == soft_right)
        		printf("Slight Right");
        	else if (currDirection == hard_right)
        		printf("Hard Right");
        }

        // set "last" variables
        lastDirection = currDirection;
        lastSpeed = currSpeed;
    }
}

/**
 * @brief LED Output Task
 *
 * @details
 * X
 *
 */
static void	LEDOutputTask(void * p_arg)
{
    RTOS_ERR  err;
    OS_FLAGS flaggedFlags;
    // Prevent Compiler Warning
    PP_UNUSED_PARAM(p_arg);

    while (INFINITE_LOOP)
    {
    	// pend for changes to alert led output flags
    	flaggedFlags = OSFlagPend(&LEDOutputFlags,
    								ALERT_FLAG_ALL,
									FLAG_PEND_FOREVER,
									(OS_OPT_PEND_FLAG_SET_ANY + OS_OPT_PEND_FLAG_CONSUME + OS_OPT_PEND_BLOCKING),
									NULL,
									&err);
		APP_RTOS_ASSERT_DBG((RTOS_ERR_CODE_GET(err) == RTOS_ERR_NONE), 1);

		// set/clear speed alert if necessary
		if (flaggedFlags & ALERT_FLAG_SPEED_SET)
			GPIO_PinOutSet(LED0_port, LED0_pin);
		else if (flaggedFlags & ALERT_FLAG_SPEED_CLEAR)
			GPIO_PinOutClear(LED0_port, LED0_pin);
		// set/clear direction alert if necessary
		if (flaggedFlags & ALERT_FLAG_DIRECTION_SET)
			GPIO_PinOutSet(LED1_port, LED1_pin);
		else if (flaggedFlags & ALERT_FLAG_DIRECTION_CLEAR)
			GPIO_PinOutClear(LED1_port, LED1_pin);
    }
}

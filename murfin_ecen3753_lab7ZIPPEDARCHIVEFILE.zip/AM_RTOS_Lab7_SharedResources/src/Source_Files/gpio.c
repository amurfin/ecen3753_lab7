//***********************************************************************************
// Include files
//***********************************************************************************
#include "gpio.h"
#include "capsense.h"

//***********************************************************************************
// defined files
//***********************************************************************************

//***********************************************************************************
// global variables
//***********************************************************************************
bool pb0_status;
bool pb1_status;
int cap_status;

/**
 * @brief
 * Pointer to hold head of button event fifo queue, global, since it must be accessed
 * by gpio.c
 *
 * @notes
 * This will start as null (empty queue) and will be filled by the button ISRs, and
 * emptied (read) by the speed setpoint task.  It will be empty, presumably most of the time
 * - which is fine!  But this will always point to the head, empty or not.
 */
static struct btn_evt_node_t * btnEvtFifoHead = NULL;

//***********************************************************************************
// function prototypes
//***********************************************************************************

//***********************************************************************************
// functions
//***********************************************************************************
/***************************************************************************//**
 * @brief Unified GPIO Interrupt handler (pushbuttons)
 *        PB0 Switches between analog and digital clock modes
 *        PB1 Increments the time by one minute
 *****************************************************************************/
void GPIO_Unified_IRQ(void) {
	RTOS_ERR err;

	// let OS know we are in ISR
	OSIntEnter();

	/* Get and clear all pending GPIO interrupts */
	uint32_t interruptMask = GPIO_IntGet();
	GPIO_IntClear(interruptMask);

	// Check if button 0 was interrupted
	// if so, push state change to fifo and post to speed setpoint semaphore
	if (interruptMask & (1 << BUTTON0_pin))
	{
		// if nothing already in queue, create it and push button 0 state change
		if (is_empty(&btnEvtFifoHead))
			btnEvtFifoHead = create_queue(btn0);
		else
			push(&btnEvtFifoHead, btn0);
		// post to speed setpoint semaphore
//		postButtonSemaphore();
	}
	// check if button 1 was interrupted
	//if so, push state change to fifo and post to speed setpoint semaphore
	if (interruptMask & (1 << BUTTON1_pin))
	{
		// if nothing already in queue, create it and push button 1 state change
		if (is_empty(&btnEvtFifoHead))
			btnEvtFifoHead = create_queue(btn1);
		else
			push(&btnEvtFifoHead, btn1);
		// post to speed setpoint semaphore
//		postButtonSemaphore();
	}

	// let OS know we're leaving the ISR
	OSIntExit();

	// post to semaphore if button was pushed
	if (interruptMask & 0xC0)
		postButtonSemaphore();
}

/***************************************************************************//**
 * @brief GPIO Interrupt handler for even pins
 ******************************************************************************/
void GPIO_EVEN_IRQHandler(void) {
	GPIO_Unified_IRQ();
}

/***************************************************************************//**
 * @brief GPIO Interrupt handler for odd pins
 ******************************************************************************/
void GPIO_ODD_IRQHandler(void) {
	GPIO_Unified_IRQ();
}

/***************************************************************************//**
 * @brief  Sets up all GPIO pins. This case the LEDS and BUTTONS
 ******************************************************************************/
void gpio_open(void) {

	/*LED 0 SETUP*/
	// Set LED ports to be standard output drive with default off (cleared)
	GPIO_DriveStrengthSet(LED0_port, gpioDriveStrengthStrongAlternateStrong);
	GPIO_PinModeSet(LED0_port, LED0_pin, gpioModePushPull, LED0_default);

	/*LED 1 SETUP*/
	GPIO_DriveStrengthSet(LED1_port, gpioDriveStrengthStrongAlternateStrong);
	GPIO_PinModeSet(LED1_port, LED1_pin, gpioModePushPull, LED1_default);

	/*BUTTON 0 SETUP*/
	GPIO_PinModeSet(BUTTON0_port, BUTTON0_pin, gpioModeInputPull,
	BUTTON0_default);

	/*BUTTON 1 SETUP*/
	GPIO_PinModeSet(BUTTON1_port, BUTTON1_pin, gpioModeInputPull,
	BUTTON1_default);

	/*CAPSENSOR Setup*/
	CAPSENSE_Init();

	//Set global variables to default values
	pb0_status = PB0_STATUS_default;
	pb1_status = PB1_STATUS_default;
	cap_status = CAP_STATUS_default;

	/*Enable interrupts*/

	//enable a rising edge only interrupt on each push button
	GPIO_IntConfig(BUTTON0_port, BUTTON0_pin, true, false, true);
	GPIO_IntConfig(BUTTON1_port, BUTTON1_pin, true, false, true);

	//Enable GPIO interupts
	NVIC_ClearPendingIRQ(GPIO_EVEN_IRQn);
	NVIC_EnableIRQ(GPIO_EVEN_IRQn);

	NVIC_ClearPendingIRQ(GPIO_ODD_IRQn);
	NVIC_EnableIRQ(GPIO_ODD_IRQn);


}

/*
 * Sets the global variable pb0_status to the current state of the button,
 * where 1 means the button is pressed and 0 means that the button is not pressed.
 */
void sample_pb0() {
	pb0_status = !GPIO_PinInGet(BUTTON0_port, BUTTON0_pin);
}

/*
 * @brief Sets the global variable pb1_status to the current state of the button,
 * where 1 means the button is pressed and 0 means that the button is not pressed.
 */
void sample_pb1() {
	pb1_status = !GPIO_PinInGet(BUTTON1_port, BUTTON1_pin);
}

/*
 * Sets the global variable cap_status to the state of the capacitive sensor, where 0 means the left side is pressed, 1 means that
 * the right side is pressed, and -1 means that either no side is pressed or both are.
 */
void sample_cap() {
	CAPSENSE_Sense();
	bool left_pressed = CAPSENSE_getPressed(LEFT_CHANNEL)
			|| CAPSENSE_getPressed(LEFT_C_CHANNEL);
	bool right_pressed = CAPSENSE_getPressed(RIGHT_CHANNEL)
			|| CAPSENSE_getPressed(RIGHT_C_CHANNEL);
	if (left_pressed && !right_pressed) { //left side pressed
		cap_status = 0;
	} else if (!left_pressed && right_pressed) { //right side pressed
		cap_status = 1;
	} else { //both or no side is pressed
		cap_status = -1;
	}
}

// same as sample_cap but puts status of capsense in a return variable instead of global variable
// return: 0 = left, 1 = right, 2 = both, -1 = none
int8_t sample_cap_OS(void)
{
	CAPSENSE_Sense();
	bool left_pressed = CAPSENSE_getPressed(LEFT_CHANNEL)
			|| CAPSENSE_getPressed(LEFT_C_CHANNEL);
	bool right_pressed = CAPSENSE_getPressed(RIGHT_CHANNEL)
			|| CAPSENSE_getPressed(RIGHT_C_CHANNEL);
	if (left_pressed && !right_pressed) { //left side pressed
		return 0;
	} else if (!left_pressed && right_pressed) { //right side pressed
		return 1;
	} else if (left_pressed && right_pressed)
		return 2;
	else
		return -1;
}

/*
 * Turns on LED0 if the left side of the touch sensor is touched or push button 0 is pressed.
 * If both buttons is pressed or the opposite button and side of the touch sensor are pressed,
 * the LED will not turn on.
 * */
void set_LED0() {
	if ((cap_status == 0)
			|| (pb0_status && !pb1_status)) { //Turn on LED0
		GPIO_PinOutSet(LED0_port, LED0_pin);
	} else { //Turn off the LEDS
		GPIO_PinOutClear(LED0_port, LED0_pin);
	}

}
/*
 * Turns on LED1 if the right side of the touch sensor is touched or push button 1 is pressed.
 * If both buttons is pressed or the opposite button and side of the touch sensor are pressed,
 * the LED will not turn on.
 * */
void set_LED1() {
	if ((cap_status == 1)
			|| (!pb0_status && pb1_status)) { //Turn on LED1
		GPIO_PinOutSet(LED1_port, LED1_pin);
	} else { //Turn off the LED
		GPIO_PinOutClear(LED1_port, LED1_pin);
	}
}

/*
 * Turns on LED0 if the left side of the touch sensor is touched or push button 0 is pressed.
 * If both buttons is pressed or the opposite button and side of the touch sensor are pressed,
 * the LED will not turn on.
 * */
void set_LED0_pbOnlyTest() {
	if (pb0_status && !pb1_status) { //Turn on LED0
		GPIO_PinOutSet(LED0_port, LED0_pin);
	} else { //Turn off the LEDS
		GPIO_PinOutClear(LED0_port, LED0_pin);
	}

}
/*
 * Turns on LED1 if the right side of the touch sensor is touched or push button 1 is pressed.
 * If both buttons is pressed or the opposite button and side of the touch sensor are pressed,
 * the LED will not turn on.
 * */
void set_LED1_pbOnlyTest() {
	if (!pb0_status && pb1_status) { //Turn on LED1
		GPIO_PinOutSet(LED1_port, LED1_pin);
	} else { //Turn off the LED
		GPIO_PinOutClear(LED1_port, LED1_pin);
	}

}

// regardless of any input conditions, sets LEDs to desired condition
// used w/full RTOS implementation (lab 6)
void set_LEDs_raw(bool led0_output, bool led1_output)
{
	// LED0
	if (led0_output == true)
		GPIO_PinOutSet(LED0_port, LED0_pin);
	else
		GPIO_PinOutClear(LED0_port, LED0_pin);

	// LED1
	if (led1_output == true)
		GPIO_PinOutSet(LED1_port, LED1_pin);
	else
		GPIO_PinOutClear(LED1_port, LED1_pin);
}

/**
 * @brief
 * OS Helper function, returns last state change from button event fifo and pops it
 */
state_change_t getLastStateChange(void)
{
	state_change_t last_state_change = peek(&btnEvtFifoHead);
	pop(&btnEvtFifoHead);
	return last_state_change;
}

///// BUTTON EVENT FIFO QUEUE FUNCTIONS /////
//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Creates a queue.
///
/// @param[in] state_change The state change type for the new head element
///
/// @return the head of the new queue
///
//----------------------------------------------------------------------------------------------------------------------------------
struct btn_evt_node_t* create_queue(state_change_t state_change) {
    struct btn_evt_node_t * head = NULL;
    if (is_empty(&head))
    {
    	head = create_new_node(state_change);
    	return head;
    }
    else
    	return NULL;
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Create a new node for the queue
///
/// @param[in] state_change
///	State change type for the new node
///
/// @return a newly allocated task
//----------------------------------------------------------------------------------------------------------------------------------
struct btn_evt_node_t* create_new_node(state_change_t state_change) {
    struct btn_evt_node_t * newNode = (struct btn_evt_node_t *) malloc(sizeof(struct btn_evt_node_t));
    newNode->state_change = state_change;
    newNode->next = NULL;
    return newNode;
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Returns the state change type of the top node in the queue
///
/// @param head The head of the queue
///
/// @return the state change type at the top of the queue
//----------------------------------------------------------------------------------------------------------------------------------
state_change_t peek(struct btn_evt_node_t** head) {
    return (* head)->state_change;
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Removes the element at the top of the queue.
///
/// @param head The head of the queue.
//----------------------------------------------------------------------------------------------------------------------------------
void pop(struct btn_evt_node_t** head) {
    struct btn_evt_node_t * oldHead = * head;
    (*head) = (*head)->next;
    free(oldHead);
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Push a new state change into the queue
///
/// @param head The head of the queue
/// @param state_change The state_change to be put into the queue
//----------------------------------------------------------------------------------------------------------------------------------
void push(struct btn_evt_node_t** head, state_change_t state_change) {
    struct btn_evt_node_t * currNode = * head;
    struct btn_evt_node_t * newNode = create_new_node(state_change);
    while (currNode->next != NULL)
        currNode = currNode->next;
    newNode->next = NULL;
    currNode->next = newNode;
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Determines whether the specified head is empty.
///
/// @param head The head of the Queue
///
/// @return True if the specified head is empty, False otherwise.
//----------------------------------------------------------------------------------------------------------------------------------
bool is_empty(struct btn_evt_node_t** head) {
    if ((*head) == NULL)
        return true;
    else
        return false;
}

//----------------------------------------------------------------------------------------------------------------------------------
/// @brief Remove all items from the queue
///
/// @param head The head of the queue
//----------------------------------------------------------------------------------------------------------------------------------
void empty_queue(struct btn_evt_node_t** head) {
    while (!is_empty(head))
        pop(head);
}

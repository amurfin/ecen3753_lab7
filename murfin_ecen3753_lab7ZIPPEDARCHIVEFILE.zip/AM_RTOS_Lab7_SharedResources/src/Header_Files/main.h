//***********************************************************************************
// Include files
//***********************************************************************************

#include <stdint.h>
#include <stdbool.h>

//***********************************************************************************
// defined files
//***********************************************************************************
#define LAB2_USE_INTERRUPT true
#define	INFINITE_LOOP		true

// Micrium OS Task Defines
#define	MAIN_START_TASK_PRIO			21u
#define	MAIN_START_TASK_STK_SIZE		512u
#define	IDLE_TASK_PRIO					22u
#define	IDLE_TASK_STK_SIZE				64u
#define	SPEED_SETPOINT_TASK_PRIO		1u
#define SPEED_SETPOINT_TASK_STK_SIZE	512u
#define	VEHICLE_DIRECTION_TASK_PRIO		2u
#define VEHICLE_DIRECTION_TASK_STK_SIZE	512u
#define	VEHICLE_MONITOR_TASK_PRIO		3u
#define VEHICLE_MONITOR_TASK_STK_SIZE	512u
#define	LCD_DISPLAY_TASK_PRIO			4u
#define LCD_DISPLAY_TASK_STK_SIZE		512u
#define	LED_OUTPUT_TASK_PRIO			5u
#define LED_OUTPUT_TASK_STK_SIZE		512u
// Event Flag Definitions
#define EVENT_FLAGS_INITILZIED_CLEAR	0u
#define VEHICLE_MONITOR_FLAG_SPEED		(1u << 0)
#define VEHICLE_MONITOR_FLAG_DIRECTION	(1u << 1)
#define	VEHICLE_MONITOR_FLAG_ALL		(VEHICLE_MONITOR_FLAG_SPEED | VEHICLE_MONITOR_FLAG_DIRECTION)
#define LED_OUTPUT_ALERT_FLAG			(1u << 0)
#define FLAG_PEND_FOREVER				0u
#define ALERT_FLAG_SPEED_SET			(1u << 0)
#define	ALERT_FLAG_SPEED_CLEAR			(1u << 1)
#define ALERT_FLAG_DIRECTION_SET		(1u << 2)
#define ALERT_FLAG_DIRECTION_CLEAR		(1u << 3)
#define ALERT_FLAG_ALL					0xF
// Semaphore Definitions
#define	SEM_INITIALIZED_CLEAR			0u
#define	SEM_PEND_FOREVER				0u
// mutex definitions
#define	MUTEX_PEND_FOREVER				0u

// random definitions
// slider input period = value / 10 (seconds)
#define	SLIDER_INPUT_PERIOD				1u

/**
 * @brief
 * Struct for "speed setpoint" shared data structure
 *
 * @param curr_speed
 * Current speed of vehicle
 *
 * @param cnt_increments
 * Number of increment commands sent
 *
 * @param cnt_decrements
 * Number of decrement commands sent
 */
typedef struct speed_setpoint {
	uint16_t curr_speed;
	uint16_t cnt_increments;
	uint16_t cnt_decrements;
} speed_setpoint;

/**
 * @brief Structure for "vehicle direction" shared data struct
 *
 * @param curr_direction
 * Current direction of vehicle
 *
 * @param cnt_...
 * Number of commands to turn a specific direction (hard left/right, soft left/right, or straight)
 *
 */
typedef enum direction_t {
	no_direction,
	hard_left, 			// = left 90 degrees
	soft_left, 			// = left 45 degrees
	straight_forward,	// = 0 degrees
	soft_right,			// = right 45 degrees
	hard_right			// = right 90 degrees
} direction_t;

typedef struct direction_setpoint {
	direction_t curr_direction;
	uint16_t cnt_hard_lefts;
	uint16_t cnt_soft_lefts;
	uint16_t cnt_straight_forwards;
	uint16_t cnt_soft_rights;
	uint16_t cnt_hard_rights;
	bool directionCollisionWarning;
} direction_setpoint;



//***********************************************************************************
// global variables
//***********************************************************************************


//***********************************************************************************
// function prototypes
//***********************************************************************************
void postButtonSemaphore(void);
